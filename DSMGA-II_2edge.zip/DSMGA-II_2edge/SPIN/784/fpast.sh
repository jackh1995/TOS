cp /home/andy3466/FastEfficientP3/problem_files/IsingSpinGlass_pm_784_2.txt 784_2   
